package de.unistuttgart.dsaws2018.ex04.p1;

public class BinaryTreeNode<T extends Comparable<T>> implements IBinaryTreeNode<T> {
	
	
	public BinaryTreeNode() {
		// TODO: to be completed
	}


}

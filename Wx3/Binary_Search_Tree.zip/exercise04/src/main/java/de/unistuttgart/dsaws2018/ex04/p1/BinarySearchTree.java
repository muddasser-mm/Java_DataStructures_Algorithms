package de.unistuttgart.dsaws2018.ex04.p1;

public class BinarySearchTree<T extends Comparable<T>> implements IBinarySearchTree<T> {
	
	
	public BinarySearchTree() {
		// TODO: to be completed
	}


}

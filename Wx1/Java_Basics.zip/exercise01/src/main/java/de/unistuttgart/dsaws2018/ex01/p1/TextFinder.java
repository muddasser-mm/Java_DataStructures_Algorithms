package de.unistuttgart.dsaws2018.ex01.p1;

public class TextFinder {

}

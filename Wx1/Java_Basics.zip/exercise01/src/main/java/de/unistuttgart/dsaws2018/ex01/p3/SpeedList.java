package de.unistuttgart.dsaws2018.ex01.p3;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class SpeedList<T> implements ISpeedList<T>, ISpeedListIterable<T> {
	
	private class Node {

	}
	
	private class SpeedListIterator implements Iterator<T> {

	}
	
	private class SpeedListSkippingIterator implements Iterator<T> {

	}

}

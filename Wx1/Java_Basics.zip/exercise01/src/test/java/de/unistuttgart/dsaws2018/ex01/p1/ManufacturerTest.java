package de.unistuttgart.dsaws2018.ex01.p1;

import static org.junit.Assert.*;

import org.junit.Test;

public class ManufacturerTest {

	@Test
	public void test() {
		assertTrue(true);
	}

}

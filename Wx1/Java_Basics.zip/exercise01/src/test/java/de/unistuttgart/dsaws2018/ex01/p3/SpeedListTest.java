package de.unistuttgart.dsaws2018.ex01.p3;

import static org.junit.Assert.*;

import org.junit.Test;

public class SpeedListTest {
	
	@Test
	public void test() {
		assertTrue(true);
	}

}

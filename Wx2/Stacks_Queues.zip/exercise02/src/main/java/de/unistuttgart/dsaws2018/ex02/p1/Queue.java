package de.unistuttgart.dsaws2018.ex02.p1;


public class Queue<T> implements IQueue<T> {
	

}
